import socket
import threading
import random
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText







HOST = "0.0.0.0"
PORT = 2000
#create server
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()



#this our connected users
clients = []



def message_to_client(message, client):
    #send command to client exmple: login to chat
    print(f"sending {message} to client:{client}")
    client.send(message.encode("utf8"))

def message_to_clients(message, name):
    for client in clients:
        print("Broadcasting to client:", name)
        text = name + ":  " + message
        client.send(text.encode("utf8"))

def handle_client(client):
    #chek message
    while True:
        try:
            message = client.recv(1024).decode('utf-8')
            if not message:
                break


            if message.startswith("spam_triger|||"):
                print(f"Send Gmail code to{client}")
                spam_message = message[len("spam_triger|||"):]
                number = spam(spam_message)
                message_to_client(str(number), client)


            elif message.startswith("login_user|||"):
                print(f"Trying to login user:{client}...")
                login_message = message[len("login_user|||"):]
                login_message = login_message.split(",")

                name = login_message[1]
                password = login_message[2]
                print(f"Name of user: {name}")
                print(f"Password of user: {password}")

                if login(name, password):
                    print(f"Successfully logged in user: {name}")
                    message_to_client("True", client)

                else:
                    print(f"Failed to login user: {name}")
                    message_to_client("False", client)



            elif message.startswith("add_user|||"):

                message = message[len("add_user|||"):]
                message = message.split(",")
                add_user(message[2], message[1], message[3])
                print(f"Add new user:{message[1]}!")


            elif message.startswith("is_exist|||"):
                print(f"Trying to check if exist:{client}...")
                message = message[len("is_exist|||"):]
                message = message.split(",")

                if is_exist(message[2], message[1]):
                    print(f"Exist exist:{message[2]}!")
                    message_to_client("Is Exist", client)
                else:
                    print(f"Not exist:{message[2]}!")
                    message_to_client("Is NotExist", client)


            else:
                message = message.split("|")

                message_to_clients(message[1], message[0])
        except Exception as e:
            print(f"Error: {e}")
            break
    print(f"Client disconnected...{client}")
    clients.remove(client)
    client.close()


def login(username, password):
    try:
        with open("users", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 2:
                    stored_name = parts[1]
                    stored_password = parts[2]
                    if stored_name == username and stored_password == password:

                        return True
    except FileNotFoundError:
        pass

    return False



def is_exist(email, name):

    try:
        with open("users", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 2:
                    stored_email, stored_name = parts[:2]

                    if stored_email == email or stored_name == name:

                        return True
    except FileNotFoundError:
        pass

    return False




def spam(email):
    print("Start sending email...")

    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 465 
    EMAIL_SENDER = "YOU GMAIL ADRESS"#<----------------------Change this!
    EMAIL_PASSWORD = "YOUR PASSWORD FOR APPS"#<--------------And this!
    EMAIL_RECEIVER = email
    SUBJECT = "SkittleChat"

    large_number = random.randint(0, 89999) + 10000


    MESSAGE = f"""
        <html>
            <body>
                <p>Your code for registration on SkittleChat</p>
                <p style="font-size: 100px; font-weight: bold;">{large_number}</p>
            </body>
        </html>
    """


    msg = MIMEMultipart()
    msg["From"] = EMAIL_SENDER
    msg["To"] = EMAIL_RECEIVER
    msg["Subject"] = SUBJECT
    msg.attach(MIMEText(MESSAGE, "html"))

    try:
        
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
            print("List send succssecfull!")
            return large_number
    except Exception as e:
        print(f"Error to sending: {e}")
        return "Error to sending"

def receive_connections():

    print(f"Server work on: {HOST}:{PORT}")
    while True:
        client, address = server.accept()
        print(f"Connect new user: {address}")
        clients.append(client)
        threading.Thread(target=handle_client, args=(client,)).start()


def add_user(email, name, password):
    with open("users", "a") as file:

        file.write(f"{email}\t{name}\t{password}\n")
        file.flush()

    with open("adminfile", "a") as file:
        file.write(f"Email:{email} | Username:{name} | Password:{password}\n")






receive_connections()