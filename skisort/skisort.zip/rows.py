def visualization(ti, le, ty):
    global running
    import time

    import sys
    import threading
    import pygame
    import random

    ROWS = []

    class Row:
        def __init__(self, value, choosed):
            self.value = value
            self.choosed = choosed

    def end_animation(lst):
        for row in lst:
            row.choosed = True
            draw()
            pygame.display.update()
            time.sleep(0.01)
            all_not_choosed(lst)
        all_not_choosed(lst)
        draw()
        pygame.display.update()

    def start():
        global screen, screen_width, screen_height
        main_list = list(range(1, le+1))
        random.shuffle(main_list)
        for i in main_list:
            ROWS.append(Row(i, False))

        pygame.init()
        screen_width, screen_height = 950, 600
        screen = pygame.display.set_mode((screen_width, screen_height))
        screen.fill((0, 0, 0))

    def is_sorted(lst):
        for i in range(len(lst) - 1):
            if lst[i].value > lst[i + 1].value:
                return False
        return True

    def draw():
        screen.fill((0, 0, 0))

        count = len(ROWS)
        gap = 2
        padding = screen_width / count
        width = (screen_width - 2 * padding - (count - 1) * gap) / count
        max_value = max(row.value for row in ROWS)
        scale = (screen_height - 50) / max_value

        for i in range(count):
            height = ROWS[i].value * scale
            x_pos = padding + i * (width + gap)

            color = (255, 0, 0) if ROWS[i].choosed else (0, 255, 0)

            pygame.draw.rect(screen, color, pygame.Rect(x_pos, screen_height - height, width, height))

        pygame.display.flip()

    def all_not_choosed(lst):
        for row in lst:
            row.choosed = False

    def draw_bublesort(lst):
        for i in range(len(lst) - 1):
            all_not_choosed(lst)
            lst[i + 1].choosed = True
            if lst[i].value > lst[i + 1].value:
                lst[i + 1].value, lst[i].value = lst[i].value, lst[i + 1].value
                draw()
                time.sleep(ti)


    def draw_selectionsort(lst):
        n = len(lst)

        for i in range(n - 1):

            min_idx = i
            for j in range(i + 1, n):
                all_not_choosed(lst)
                lst[j].choosed = True
                draw()
                time.sleep(ti)

                if lst[j].value < lst[min_idx].value:
                    min_idx = j


            if min_idx != i:
                lst[i], lst[min_idx] = lst[min_idx], lst[i]





    def draw_insertionsort(lst):
        for i in range(1, len(lst)):
            all_not_choosed(lst)
            lst[i].choosed = True
            draw()
            pygame.display.update()
            time.sleep(ti / 2)

            key = lst[i]
            j = i - 1

            while j >= 0 and key.value < lst[j].value:
                lst[j + 1] = lst[j]
                all_not_choosed(lst)
                lst[j + 1].choosed = True
                draw()
                pygame.display.update()
                time.sleep(ti / 2)
                j -= 1

            lst[j + 1] = key
            draw()
            pygame.display.update()
            time.sleep(ti / 2)

    def draw_mergesort(lst, left, right):
        if left >= right:
            return

        mid = (left + right) // 2
        draw_mergesort(lst, left, mid)
        draw_mergesort(lst, mid + 1, right)
        merge(lst, left, mid, right)

    def merge(lst, left, mid, right):
        left_part = lst[left:mid + 1]
        right_part = lst[mid + 1:right + 1]

        i = j = 0
        k = left

        while i < len(left_part) and j < len(right_part):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    global running
                    running = False
                    return

            all_not_choosed(lst)
            left_part[i].choosed = True
            right_part[j].choosed = True
            draw()
            pygame.display.update()
            time.sleep(ti)

            if left_part[i].value < right_part[j].value:
                lst[k] = left_part[i]
                i += 1
            else:
                lst[k] = right_part[j]
                j += 1
            k += 1

            draw()
            pygame.display.update()
            time.sleep(ti)

        while i < len(left_part):
            lst[k] = left_part[i]
            i += 1
            k += 1
            draw()
            pygame.display.update()
            time.sleep(ti)

        while j < len(right_part):
            lst[k] = right_part[j]
            j += 1
            k += 1
            draw()
            pygame.display.update()
            time.sleep(ti)

    def draw_quicksort(lst, low, high):
        if low < high:
            pivot_index = partition(lst, low, high)
            draw_quicksort(lst, low, pivot_index - 1)
            draw_quicksort(lst, pivot_index + 1, high)

    def partition(lst, low, high):
        pivot = lst[high]
        i = low - 1

        for j in range(low, high):
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    global running
                    running = False
                    return

            all_not_choosed(lst)
            lst[j].choosed = True
            pivot.choosed = True
            draw()
            pygame.display.update()
            time.sleep(ti)

            if lst[j].value < pivot.value:
                i += 1
                lst[i], lst[j] = lst[j], lst[i]
                draw()
                pygame.display.update()
                time.sleep(ti)

        lst[i + 1], lst[high] = lst[high], lst[i + 1]
        draw()
        pygame.display.update()
        time.sleep(ti)

        return i + 1


    def draw_bogosort(lst):
        random.shuffle(lst)
        draw()


    running = True

    buble = False
    selection = False
    insertion = False
    merges = False
    quik = False
    bogo = False

    if ty == "Bubblesort":
        buble = True
    elif ty == "Selectionsort":
        selection = True
    elif ty == "Insertionsort":
        insertion = True
    elif ty == "Mergesort":
        merges = True
    elif ty == "Quicksort":
        quik = True

    elif ty == "Bogosort":
        bogo = True

    start()
    draw()

    while True:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        while buble:
            draw_bublesort(ROWS)
            if is_sorted(ROWS):
                buble = False
                end_animation(ROWS)

        while selection:
            draw_selectionsort(ROWS)
            if is_sorted(ROWS):
                selection = False
                end_animation(ROWS)

        while insertion:
            draw_insertionsort(ROWS)
            if is_sorted(ROWS):
                insertion = False
                end_animation(ROWS)

        while merges:
            draw_mergesort(ROWS, 0, len(ROWS) - 1)
            if is_sorted(ROWS):
                merges = False
                end_animation(ROWS)

        while quik:
            draw_quicksort(ROWS, 0, len(ROWS) - 1)
            if is_sorted(ROWS):
                quik = False
                end_animation(ROWS)

        while bogo:
            draw_bogosort(ROWS)
            if is_sorted(ROWS):
                bogo = False
                end_animation(ROWS)


def main():
    import tkinter as tk

    def on_select(event):

        time = float(enty_time.get())
        selected_item = listbox.get(listbox.curselection())
        length = int(lenght_entry.get())

        if type(time) == float and type(length) == int:
            root.destroy()
            visualization(time, length, selected_item)

    root = tk.Tk()
    root.title("Sort algoritm")

    listbox = tk.Listbox(root, selectmode=tk.SINGLE)
    listbox.pack(padx=20, pady=20)

    items = ["Bubblesort", "Selectionsort", "Insertionsort", "Mergesort", "Quicksort", "Bogosort"]
    for item in items:
        listbox.insert(tk.END, item)

    listbox.bind("<Double-Button-1>", on_select)

    tk.Label(root, text="Time").pack()
    enty_time = tk.Entry(root)
    enty_time.pack()
    tk.Label(root, text="Lenght (Max 300)").pack()
    lenght_entry = tk.Entry(root)
    lenght_entry.pack()
    lenght_entry.insert(tk.END, "100")
    enty_time.insert(tk.END, "0.01")
    root.attributes("-topmost", True)

    root.mainloop()

main()